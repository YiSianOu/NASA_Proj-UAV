/* GCC/Clang, Linux. Each access to the UIO mapping has an explicit 32-bit width.
 * Example build on ARM64:
 * gcc -O2 -ffreestanding -shared -fPIC -nostdlib -o libuio_mmio.so uio_mmio.c
 */
#include <stdint.h>

_Static_assert(sizeof(uint32_t) == 4, "32-bit MMIO is required");

static inline void before_mmio(void)
{
#if defined(__aarch64__)
    __asm__ __volatile__("dmb sy" ::: "memory");
#else
    __sync_synchronize();
#endif
}

static inline void after_mmio(void)
{
#if defined(__aarch64__)
    __asm__ __volatile__("dsb sy" ::: "memory");
#else
    __sync_synchronize();
#endif
}

void uio_write32(void *base, uint32_t value)
{
    volatile uint32_t *command = (volatile uint32_t *)base;
    before_mmio();
    *command = value;
    after_mmio();
}

void uio_read_frame(void *base, uint32_t *output)
{
    volatile uint32_t *data = (volatile uint32_t *)((unsigned char *)base + 0x0c);
    before_mmio();
    for (unsigned int i = 0; i < 256; ++i) {
        output[i] = *data;
    }
    after_mmio();
}
